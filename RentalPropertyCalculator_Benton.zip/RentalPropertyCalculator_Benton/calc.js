
function valueCopy(){
	
	document.getElementById("data1_e").value = document.getElementById("c_data1").value;
	document.getElementById("data2_e").value = document.getElementById("c_data2").value;
	document.getElementById("data3_e").value = document.getElementById("c_data3").value;
	document.getElementById("data4_e").value = document.getElementById("c_data4").value;
	document.getElementById("data5_e").value = document.getElementById("c_data5").value;
	document.getElementById("data6_e").value = document.getElementById("c_data6").value;
	document.getElementById("data6b_e").value = document.getElementById("c_data6b").value;
	document.getElementById("data7_e").value = document.getElementById("c_data7").value;
	document.getElementById("data8_e").value = document.getElementById("c_data8").value;
	
	document.getElementById("CoC_result_e").value = document.getElementById("CoC_result").value;
	document.getElementById("c_result_e").value = document.getElementById("c_result").value;
	document.getElementById("plusROI_result_e").value = document.getElementById("plusROI_result").value;
	document.getElementById("ROI_result_e").value = document.getElementById("ROI_result").value;
	document.getElementById("CAP_result_e").value = document.getElementById("CAP_result").value;
	document.getElementById("GRM_result_e").value = document.getElementById("GRM_result").value;
	document.getElementById("MORG_result_e").value = document.getElementById("MORG_result").value;
        document.getElementById("EXP_result_e").value = document.getElementById("EXP_result").value;
        document.getElementById("VAC_result_e").value = document.getElementById("VAC_result").value;
	document.getElementById("DOWN_result_e").value = document.getElementById("DOWN_result").value;
	document.getElementById("CASH_result_e").value = document.getElementById("CASH_result").value;
	document.getElementById("LOAN_result_e").value = document.getElementById("LOAN_result").value;
}


function resetInput(){

	document.getElementById("c_data1").value = 60000;
	document.getElementById("c_data2").value = 20;
	document.getElementById("c_data3").value = 3;
	document.getElementById("c_data4").value = 360;
	document.getElementById("c_data5").value = 750;
	document.getElementById("c_data6").value = 35;
	document.getElementById("c_data6b").value = 0;
	document.getElementById("c_data7").value = 2000;
	document.getElementById("c_data8").value = 5;
	
	calculate();
}

function clearOutput(){
	
	document.getElementById("CoC_result").value = " --";
	document.getElementById("c_result").value = " --";
	document.getElementById("MORG_result").value = " --";
	document.getElementById("EXP_result").value = " --";
	document.getElementById("VAC_result").value = " --";
	document.getElementById("DOWN_result").value = " --";
	document.getElementById("CASH_result").value = " --";
	document.getElementById("LOAN_result").value = " --";
	document.getElementById("plusROI_result").value = " --";
	document.getElementById("ROI_result").value = " --";
	document.getElementById("CAP_result").value = " --";
	document.getElementById("GRM_result").value = " --";		

	
	document.getElementById("CoCchart").style.opacity = 0.2;
	document.getElementById("DOWNchart").style.opacity = 0.2;
}


// ------------- chart 1 -------------------------------------------------------------

function getChart1(){
	
	getChart2();
	
	var ctx = document.getElementById("chart1").getContext("2d");

	var startData = {	
		labels : ["$" + xLabel(3000),"$" + xLabel(2000),"$" + xLabel(1000),"$" + xLabel(0),"$" + xLabel(-1000),"$" + xLabel(-2000),"$" + xLabel(-3000)],
		datasets : [
			{
				fillColor : "rgba(151,187,205,0.25)",
				strokeColor : "rgba(151,187,205,1)",
				pointColor : "rgba(151,187,205,1)",
				pointStrokeColor : "#fff",
				pointHighlightFill : "#fff",
				pointHighlightStroke : "rgba(220,220,220,1)",
				data : [yData(3000),yData(2000),yData(1000),yData(0),yData(-1000),yData(-2000),yData(-3000)]	
			}
		]
	};
	var options = {
		scaleOverride: false,
		scaleGridLineColor: "rgba(0,0,0,0.15)",
		responsive: true,
		showTooltips: false,
		onAnimationProgress: function() { drawDatasetPointsLabels() },
		onAnimationComplete: function() { drawDatasetPointsLabels() },
		scaleLabel : "<%= Number(value) + '%'%>"	
	}
	var myLineChart = new Chart(ctx).Line(startData, options);
	
	function drawDatasetPointsLabels() {
		ctx.font = '.8rem "Gotham Book",sans-serif';
		ctx.fillStyle = "rgba(0,0,0,0.25)";
		ctx.textAlign="center";
		$(myLineChart.datasets).each(function(idx,dataset){
			$(dataset.points).each(function(pdx,pointinfo){
				// First dataset is shifted off the scale line. 
				// Don't write to the canvas for the null placeholder.
				if ( pointinfo.value !== null ) { 
					ctx.fillText(pointinfo.value,pointinfo.x,pointinfo.y - 15);
				}
			});
		});         
	 }
	myLineChart.update();
}

function xLabel(changeQty){
	var label = parseInt(document.getElementById("c_data1").value) + changeQty;
	return label;
}


function yData(changeQty){
	
	var closeQty = 0;
	
	if(changeQty == -3000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + -3000;
	}else if (changeQty == -2000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + -2000;
	}else if (changeQty == -1000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + -1000;
	}else if (changeQty == 0){
		closeQty = parseFloat(document.getElementById("c_data1").value);
	}else if (changeQty == 1000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + 1000;
	}else if (changeQty == 2000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + 2000;
	}else if (changeQty == 3000){
		closeQty = parseFloat(document.getElementById("c_data1").value) + 3000;
	}
	
	var pctDown = document.getElementById("c_data2").value;
	var pctIntst = document.getElementById("c_data3").value;
	var termLen = document.getElementById("c_data4").value;
	var rentQty = document.getElementById("c_data5").value;
	var pctExpse = document.getElementById("c_data6").value;
	var closeCost = document.getElementById("c_data7").value;
	var pctVacancy = document.getElementById("c_data8").value;
	
	/*Conversion of percent values to decimal form*/
	var pctDownDivided = pctDown/100;
	var pctIntstDivided = pctIntst/100;
	var pctExpseDivided = pctExpse/100;
	var pctVacancyDivided = pctVacancy/100;
	
	
	
	/* Cash Flow computation */
	var monthlyIntst = pctIntstDivided / 12;
	var loanAmount = ((closeQty * pctDownDivided) - closeQty) * -Math.abs(1);
	var monthlyMortgage = loanAmount * (monthlyIntst * Math.pow(1 + monthlyIntst, termLen)) / (Math.pow(1 + monthlyIntst, termLen)-1);
	var monthlyCashFlow = (((rentQty * (pctExpseDivided + pctVacancyDivided)) + monthlyMortgage) - rentQty) * -Math.abs(1);
	/* Made rounded cash flow a separate var so that the non-rounded value can be used later */
	var monthlyCashFlow_rounded = Math.round(100 * monthlyCashFlow)/100;
//	document.getElementById("c_result").innerHTML = "$" + monthlyCashFlow_rounded;
		
	var investedCapital = (-Math.abs(1) * ((closeQty * pctDownDivided) + parseFloat(closeCost))); // total investedCapital
	var netEarnings = monthlyCashFlow_rounded; // monthly cash flow (monthly earnings)

	investedCapital = investedCapital * -1;
	/* Coash-On-Cash Return Computations */
	var CoC = (netEarnings * 12)/investedCapital * 100;
	var resultCoC = Math.round(CoC * 100) / 100;
	
	
	return resultCoC;
}




// ----------------Chart 1 above, chart 2 below--------------------------------------------------------------------------------------------------------------------------------------------------




function getChart2(){

	var ctx = document.getElementById("chart2").getContext("2d");

	var startData = {	
		labels : ["$" + xLabel2(3000),"$" + xLabel2(2000),"$" + xLabel2(1000),"$" + xLabel2(0),"$" + xLabel2(-1000),"$" + xLabel2(-2000),"$" + xLabel2(-3000)],
		datasets : [
			{
				fillColor : "rgba(151,187,205,0.25)",
				strokeColor : "rgba(151,187,205,1)",
				pointColor : "rgba(151,187,205,1)",
				pointStrokeColor : "#fff",
				pointHighlightFill : "#fff",
				pointHighlightStroke : "rgba(220,220,220,1)",
				data : [yData2(3000),yData2(2000),yData2(1000),yData2(0),yData2(-1000),yData2(-2000),yData2(-3000)]	
			}
		]
	};
	var options = {
		scaleOverride: false,
		scaleGridLineColor: "rgba(0,0,0,0.15)",
		responsive: true,
		showTooltips: false,
		onAnimationProgress: function() { drawDatasetPointsLabels() },
		onAnimationComplete: function() { drawDatasetPointsLabels() },
		scaleLabel : "<%= Number(value) + '%'%>"	
	}
	var myLineChart2 = new Chart(ctx).Line(startData, options);
	
	function drawDatasetPointsLabels() {
		ctx.font = '.8rem "Gotham Book",sans-serif';
		ctx.fillStyle = "rgba(0,0,0,0.25)";
		ctx.textAlign="center";
		$(myLineChart2.datasets).each(function(idx,dataset){
			$(dataset.points).each(function(pdx,pointinfo){
				// First dataset is shifted off the scale line. 
				// Don't write to the canvas for the null placeholder.
				if ( pointinfo.value !== null ) { 
					ctx.fillText(pointinfo.value,pointinfo.x,pointinfo.y - 15);
				}
			});
		});         
	 }
	myLineChart2.update();
}

function xLabel2(changeQty){
	var label = parseInt(document.getElementById("c_data7").value) + changeQty;
	return label;
}


function yData2(changeQty){
	
	var closeCost = 0;
	
	if(changeQty == -3000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + -3000;
	}else if (changeQty == -2000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + -2000;
	}else if (changeQty == -1000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + -1000;
	}else if (changeQty == 0){
		closeCost = parseFloat(document.getElementById("c_data7").value);
	}else if (changeQty == 1000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + 1000;
	}else if (changeQty == 2000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + 2000;
	}else if (changeQty == 3000){
		closeCost = parseFloat(document.getElementById("c_data7").value) + 3000;
	}
	
	var closeQty = document.getElementById("c_data1").value;
	var pctDown = document.getElementById("c_data2").value;
	var pctIntst = document.getElementById("c_data3").value;
	var termLen = document.getElementById("c_data4").value;
	var rentQty = document.getElementById("c_data5").value;
	var pctExpse = document.getElementById("c_data6").value;
	var pctVacancy = document.getElementById("c_data8").value;
	
	/*Conversion of percent values to decimal form*/
	var pctDownDivided = pctDown/100;
	var pctIntstDivided = pctIntst/100;
	var pctExpseDivided = pctExpse/100;
	var pctVacancyDivided = pctVacancy/100;
	
	/* Cash Flow computation */
	var monthlyIntst = pctIntstDivided / 12;
	var loanAmount = ((closeQty * pctDownDivided) - closeQty) * -Math.abs(1);
	var monthlyMortgage = loanAmount * (monthlyIntst * Math.pow(1 + monthlyIntst, termLen)) / (Math.pow(1 + monthlyIntst, termLen)-1);
	var monthlyCashFlow = (((rentQty * (pctExpseDivided + pctVacancyDivided)) + monthlyMortgage) - rentQty) * -Math.abs(1);
	/* Made rounded cash flow a separate var so that the non-rounded value can be used later */
	var monthlyCashFlow_rounded = Math.round(100 * monthlyCashFlow)/100;
	
	
		
	var investedCapital = (-Math.abs(1) * ((closeQty * pctDownDivided) + parseFloat(closeCost))); // total investedCapital
	var netEarnings = monthlyCashFlow_rounded; // monthly cash flow (monthly earnings)

	investedCapital = investedCapital * -1;
	/* Coash-On-Cash Return Computations */
	var CoC = (netEarnings * 12)/investedCapital * 100;
	var resultCoC = Math.round(CoC * 100) / 100;
	
	
	return resultCoC;
}




// --------------------------------end of chart 2 ---------------------------------------------------




/* Prevents page refresh when form is submitted */
function c_submitHandler(){
$("#c_inCalc").submit(function () {
 calculate();
 event.preventDefault();
});
}


/* Toggles the open and close of the documentation paragraph on button click */
function toggleIntroPara(){
	if(document.getElementById("introPara").style.display == "none"){
		document.getElementById("introPara").style.display = "block";
		document.getElementById("introButton").value = "Close Documentation";
		document.getElementById("introButton").style.background = 'rgba(151,187,205,0.5)';
	}else{
		document.getElementById("introPara").style.display = "none";
		document.getElementById("introButton").value = "Open Documentation";
		document.getElementById("introButton").style.background = '#FFFFE5';
	}
	return true;
}


/* Performs data field error checking and cash flow computations */
function calculate(){
	
	
	
	
	document.getElementById("c_result").style.color = "black";
	document.getElementById("alertMsg").innerHTML = ".";
	document.getElementById("alertMsg").style.opacity = 0;
	
	
	var closeQty = document.getElementById("c_data1").value;
	var pctDown = document.getElementById("c_data2").value;
	var pctIntst = document.getElementById("c_data3").value;
	var termLen = document.getElementById("c_data4").value;
	var rentQty = document.getElementById("c_data5").value;
	var pctExpse = document.getElementById("c_data6").value;
	var amtExpse = document.getElementById("c_data6b").value;
	var closeCost = document.getElementById("c_data7").value;
	var pctVacancy = document.getElementById("c_data8").value;
	
//		alert("'" + rentQty + "'");
	
	/* Clear any yellow backgrounds from past error checking */
	if (document.getElementById("c_data1").style.backgroundColor == "yellow"){
		document.getElementById("c_data1").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data2").style.backgroundColor == "yellow"){
		document.getElementById("c_data2").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data3").style.backgroundColor == "yellow"){
		document.getElementById("c_data3").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data4").style.backgroundColor == "yellow"){
		document.getElementById("c_data4").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data5").style.backgroundColor == "yellow"){
		document.getElementById("c_data5").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data6").style.backgroundColor == "yellow"){
		document.getElementById("c_data6").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data6b").style.backgroundColor == "yellow"){
		document.getElementById("c_data6b").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data7").style.backgroundColor == "yellow"){
		document.getElementById("c_data7").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data8").style.backgroundColor == "yellow"){
		document.getElementById("c_data8").style.backgroundColor = "white";
	}
	
		
	
	
	/* Set background color of fields with invalid numeric value to yellow */		
	
	if(closeQty <= 0)
	{					
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Closing Price field must have a value greater than zero.";
					
		clearOutput();
				
//		document.getElementById("c_data1").value = "";
		document.getElementById("c_data1").style.backgroundColor = "yellow";
		return;
	}
	if(pctDown <= 0)
	{					
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Closing Price field must have a value greater than zero.";
					
		clearOutput();
				
//		document.getElementById("c_data2").value = "";
		document.getElementById("c_data2").style.backgroundColor = "yellow";
		return;
	}
	if(pctIntst <= 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Interest Rate field must have a value greater than zero.";
					
		clearOutput();
				
//		document.getElementById("c_data3").value = "";
		document.getElementById("c_data3").style.backgroundColor = "yellow";
		return;
	}
	if(termLen <= 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Term Length field must have a value greater than zero.";
					
		clearOutput();
				
//		document.getElementById("c_data4").value = "";
		document.getElementById("c_data4").style.backgroundColor = "yellow";
		return;
	}
	if(rentQty < 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Rent Income field must have a value greater than or equal to zero.";
					
		clearOutput();
				
//		document.getElementById("c_data5").value = "";
		document.getElementById("c_data5").style.backgroundColor = "yellow";
		return;
	}
	if(pctExpse < 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Expenses (%) field must have a value greater than or equal to zero.";
					
		clearOutput();
				
//		document.getElementById("c_data6").value = "";
		document.getElementById("c_data6").style.backgroundColor = "yellow";
		return;
	}
	if(amtExpse < 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Expenses ($/yr) field must have a value greater than or equal to zero.";
					
		clearOutput();
				
//		document.getElementById("c_data6b").value = "";
		document.getElementById("c_data6b").style.backgroundColor = "yellow";
		return;
	}
	if(closeCost < 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Closing Costs field must have a value greater than or equal to zero.";
					
		clearOutput();
				
//		document.getElementById("c_data7").value = "";
		document.getElementById("c_data7").style.backgroundColor = "yellow";
		return;
	}
	if(pctVacancy < 0)
	{
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: the Vacancy Loss field must have a value greater than or equal to zero.";
					
		clearOutput();
				
//		document.getElementById("c_data8").value = "";
		document.getElementById("c_data8").style.backgroundColor = "yellow";
		return;
	}
	
	
		
	
	/* Set background color of fields without a numeric value to yellow */
	if(closeQty=="" || pctDown=="" || pctIntst=="" || termLen=="" || rentQty==""
	|| pctExpse=="" || amtExpse=="" || closeCost=="" || pctVacancy==""
	|| isNaN(closeQty) || isNaN(pctDown) || isNaN(pctIntst) || isNaN(termLen)
	|| isNaN(rentQty) || isNaN(pctExpse) || isNaN(amtExpse) ||isNaN(closeCost) || isNaN(pctVacancy))
	{
		if (closeQty=="" || isNaN(closeQty)){
			document.getElementById("c_data1").style.backgroundColor = "yellow";			
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Closing Price field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
		if (pctDown=="" || isNaN(pctDown)){
			document.getElementById("c_data2").style.backgroundColor = "yellow";	
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Percent Down field does not contain a numeric value.";	

			clearOutput();
			
			return;
		}
		if (pctIntst=="" || isNaN(pctIntst)){
			document.getElementById("c_data3").style.backgroundColor = "yellow";
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Interest Rate field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
		if (termLen=="" || isNaN(termLen)){
			document.getElementById("c_data4").style.backgroundColor = "yellow";
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Term Length field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
		if (rentQty=="" || isNaN(rentQty)){
			document.getElementById("c_data5").style.backgroundColor = "yellow";
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Rent Income field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}	
		if (isNaN(pctExpse)){
			
			document.getElementById("c_data6").style.backgroundColor = "yellow";			
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Expenses (%) field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
		if (isNaN(amtExpse)){
			
			document.getElementById("c_data6b").style.backgroundColor = "yellow";			
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Expenses ($/yr) field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}		
		if (pctExpse==""){						
			if (amtExpse==""){
				document.getElementById("c_data6").style.backgroundColor = "yellow";
				document.getElementById("c_data6b").style.backgroundColor = "yellow";
				
				document.getElementById("alertMsg").style.opacity = 1;
				document.getElementById("alertMsg").style.color = "red";
				document.getElementById("alertMsg").innerHTML = "Error: at least one Expenses field must contain a valid numeric value.";
				
				clearOutput();
				
				return;
			}
		}
		if (amtExpse==""){			
			if(pctExpse==""){
				document.getElementById("c_data6").style.backgroundColor = "yellow";
				document.getElementById("c_data6b").style.backgroundColor = "yellow";
				
				document.getElementById("alertMsg").style.opacity = 1;
				document.getElementById("alertMsg").style.color = "red";
				document.getElementById("alertMsg").innerHTML = "Error: at least one Expenses field must contain a valid numeric value.";
				
				clearOutput();
				
				return;
			}
		}
		if (closeCost=="" || isNaN(closeCost)){
			document.getElementById("c_data7").style.backgroundColor = "yellow";
			
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Closing Costs field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
		if (pctVacancy=="" || isNaN(pctVacancy)){
			document.getElementById("c_data8").style.backgroundColor = "yellow";
			
			document.getElementById("alertMsg").style.opacity = 1;
			document.getElementById("alertMsg").style.color = "red";
			document.getElementById("alertMsg").innerHTML = "Error: the Vacancy Loss field does not contain a numeric value.";
			
			clearOutput();
			
			return;
		}
	}		
	
	
	if (document.getElementById("c_data6").value ==""){		
		pctExpse = 0;
	}
	if (document.getElementById("c_data6b").value ==""){		
		amtExpse = 0;
	}
		
		

	/*Conversion of percent values to decimal form*/
	var pctDownDivided = pctDown/100;
	var pctIntstDivided = pctIntst/100;
	var pctExpseDivided = pctExpse/100;
	var pctVacancyDivided = pctVacancy/100;
	var MonthlyExpenses = (pctExpseDivided * rentQty) + amtExpse/12;
	var MonthlyVacancy = pctVacancyDivided * rentQty;
	
	/* Cash Flow computation */
	var monthlyIntst = pctIntstDivided / 12;
	var loanAmount = ((closeQty * pctDownDivided) - closeQty) * -Math.abs(1);
	var monthlyMortgage = loanAmount * (monthlyIntst * Math.pow(1 + monthlyIntst, termLen)) / (Math.pow(1 + monthlyIntst, termLen)-1);
	var monthlyCashFlow = ((MonthlyExpenses + MonthlyVacancy + monthlyMortgage) - rentQty) * -Math.abs(1);
	/* Made rounded cash flow a separate var so that the non-rounded value can be used later */
	var monthlyCashFlow_rounded = Math.round(100 * monthlyCashFlow)/100;
	document.getElementById("c_result").innerHTML = "$" + monthlyCashFlow_rounded + "/mo.";
	
	
	if(parseFloat(monthlyCashFlow_rounded) >= 0.0)
	{	
		var investedCapital = (-Math.abs(1) * ((closeQty * pctDownDivided) + parseFloat(closeCost))); // total investedCapital
		investedCapital = investedCapital * -1;
		var netEarnings = monthlyCashFlow_rounded; // monthly cash flow (monthly earnings)

		/* Coash-On-Cash Return Computations */
		var CoC = (netEarnings * 12)/investedCapital * 100;
		var resultCoC = Math.abs(Math.round(CoC * 100) / 100);
		
		document.getElementById("CoC_result").innerHTML = resultCoC + "%";
		
		
		/* Gross Rent Multiplier computation */
		var GRM = closeQty/(rentQty * 12);
		var resultGRM = Math.round(GRM * 100) / 100;
		document.getElementById("GRM_result").innerHTML = resultGRM;
		
		
		
	/* The following two calculation (ROI) are modifications from the Finance.js library */
		//Finance.js
		//For more information, visit http://financejs.org
		//Copyright 2014 - 2015 Essam Al Joubori, MIT license
		
		
		// Instantiate a Finance class
		var Finance = function() {};
	
		
		/* ROI Computations */
		var resultROI  = 0; // stores result of ROI calculation
		var counter    = 0; // counts the number of calculations performed to determine number of months until break even and ROI at 12 months
		var firstYrROI = 0; // stores the ROI at month 12

		while (resultROI <= 0){
			++counter;
			netEarnings = netEarnings + monthlyCashFlow_rounded; // keep adding netEarnings to total for each month calculated
			var roi = (netEarnings - Math.abs(investedCapital)) / Math.abs(investedCapital) * 100;
			resultROI = Math.round(roi * 100) / 100;

			if (counter == 12){
				firstYrROI = resultROI;
			}
		}	
		document.getElementById("ROI_result").innerHTML = firstYrROI + "%";	
	//	document.getElementById("plusROI_result").innerHTML = Math.round(100 * (counter/12))/100 + " yrs. (" + counter + " mo.)"; // shows paypack period in years
		tempVar = Math.round((counter/12) * 100) / 100; ;
                document.getElementById("plusROI_result").innerHTML = tempVar + " yrs.";  
		
		/* Capitalization Rate (CAP Rate) computation -- divides net yearly income by value of investment*/
		var CAP = ((monthlyCashFlow_rounded * 12) / closeQty) * 100;
		var resultCAP = Math.round(CAP * 100) / 100;
		document.getElementById("CAP_result").innerHTML = resultCAP + "%";
			
		
		/* Mortgage */
		var Mortgage = Math.round(monthlyMortgage * 100) / 100;
		document.getElementById("MORG_result").innerHTML = "$" + Mortgage + "/mo.";
				
		
		/* Expenses */
		var resultExpenses = Math.round(MonthlyExpenses * 100) / 100;
		document.getElementById("EXP_result").innerHTML = "$" + resultExpenses + "/mo.";
			
			
		/* Vacancy loss */
		var resultVacancy = Math.round(MonthlyVacancy * 100) / 100;
		document.getElementById("VAC_result").innerHTML = "$" + resultVacancy + "/mo.";
			
		
		/* Down pmt */
		var downPMT = pctDownDivided * closeQty;
		var ResultDownPMT = Math.round(downPMT * 100) / 100;
		document.getElementById("DOWN_result").innerHTML = "$" + ResultDownPMT;
		
		/* Cash invested */
		var CashTot = parseFloat(downPMT) + parseFloat(closeCost);
		var ResultCashTot = Math.round(CashTot * 100) / 100;
		document.getElementById("CASH_result").innerHTML = "$" + ResultCashTot;
		
		/* Loan amount */
		var LoanAmount = (downPMT - closeQty) * -1;
		var ResultLoanAmount = Math.round(LoanAmount * 100) / 100;
		document.getElementById("LOAN_result").innerHTML = "$" + ResultLoanAmount;
				
			
		
		getChart1();
        
		valueCopy();


	}else{		
		document.getElementById("CoC_result").value = " --";
		document.getElementById("plusROI_result").value = " --";
		document.getElementById("ROI_result").value = " --";
		document.getElementById("CAP_result").value = " --";
		document.getElementById("GRM_result").value = " --";		
		document.getElementById("MORG_result").value = " --";
		document.getElementById("DOWN_result").value = " --";
		document.getElementById("CASH_result").value = " --";
		document.getElementById("LOAN_result").value = " --";
		
		document.getElementById("c_result").style.color = "red";
		document.getElementById("alertMsg").style.opacity = 1;
		document.getElementById("alertMsg").style.color = "red";
		document.getElementById("alertMsg").innerHTML = "Error: Cash Flow must be equal to or greater than zero.";
		
		document.getElementById("CoCchart").style.opacity = 0.2;
		document.getElementById("DOWNchart").style.opacity = 0.2;
		return;
	}
		if (document.getElementById("CoCchart").style.opacity == 0.2){
			document.getElementById("CoCchart").style.opacity = 1;
		}
		if (document.getElementById("DOWNchart").style.opacity == 0.2){
			document.getElementById("DOWNchart").style.opacity = 1;
		}
}

/* clears contents and error residual from data entry fields */
function clearFields(){
	
	/* Clear any yellow backgrounds from error checking when "Clear" button is clicked */
	if (document.getElementById("c_data1").style.backgroundColor == "yellow"){
		document.getElementById("c_data1").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data2").style.backgroundColor == "yellow"){
		document.getElementById("c_data2").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data3").style.backgroundColor == "yellow"){
		document.getElementById("c_data3").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data4").style.backgroundColor == "yellow"){
		document.getElementById("c_data4").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data5").style.backgroundColor == "yellow"){
		document.getElementById("c_data5").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data6").style.backgroundColor == "yellow"){
		document.getElementById("c_data6").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data6b").style.backgroundColor == "yellow"){
		document.getElementById("c_data6b").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data7").style.backgroundColor == "yellow"){			
		document.getElementById("c_data7").style.backgroundColor = "white";
	}
	if (document.getElementById("c_data8").style.backgroundColor == "yellow"){			
		document.getElementById("c_data8").style.backgroundColor = "white";
	}
	
	/* Clears the value of each field when "Clear" button is clicked */
	document.getElementById("c_data1").value = "";
	document.getElementById("c_data2").value = "";
	document.getElementById("c_data3").value = "";
	document.getElementById("c_data4").value = "";
	document.getElementById("c_data5").value = "";
	document.getElementById("c_data6").value = "";
	document.getElementById("c_data6b").value = "";
	document.getElementById("c_data7").value = "";
	document.getElementById("c_data8").value = "";
	document.getElementById("CoC_result").value = " --";
	document.getElementById("c_result").value = " --";
	document.getElementById("plusROI_result").value = " --";
	document.getElementById("ROI_result").value = " --";
	document.getElementById("CAP_result").value = " --";
	document.getElementById("GRM_result").value = " --";
	document.getElementById("MORG_result").value = " --";
	document.getElementById("EXP_result").value = " --";
	document.getElementById("VAC_result").value = " --";
	document.getElementById("DOWN_result").value = " --";
	document.getElementById("CASH_result").value = " --";
	document.getElementById("LOAN_result").value = " --";
	
	document.getElementById("alertMsg").style.opacity = 1;
	document.getElementById("alertMsg").style.color = "Blue";
	document.getElementById("c_result").style.color = "black";
	document.getElementById("alertMsg").innerHTML = "Values cleared.";
	document.getElementById("CoCchart").style.opacity = 0.2;
	document.getElementById("DOWNchart").style.opacity = 0.2;
}


/* Increments/Decrements data entry field based upon value passed from onlick func call */
function IncrementDecrement(editValue, buttonID){
	
    var tempVal = 0;
	/* Check to ensure that field corresponding with button contains either a number or is empty ("") */			
	if(buttonID == 1){	
		if(isNaN(document.getElementById("c_data1").value)){
			document.getElementById("c_data1").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data1").value == ""){
			document.getElementById("c_data1").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data1").value);
			document.getElementById("c_data1").value = tempVal + editValue;
		}
		calculate();
		
	}else if(buttonID == 2){
		if(isNaN(document.getElementById("c_data2").value)){
			document.getElementById("c_data2").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data2").value == ""){
			document.getElementById("c_data2").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data2").value);
			document.getElementById("c_data2").value = tempVal + editValue;
		}
		calculate();
		
	}else if(buttonID == 3){
		if(isNaN(document.getElementById("c_data3").value)){
			document.getElementById("c_data3").style.backgroundColor = "yellow";
			return;
		}
		if(document.getElementById("c_data3").value == ""){
			document.getElementById("c_data3").value = editValue;
		}else{
			tempVal = parseFloat(document.getElementById("c_data3").value);
			document.getElementById("c_data3").value = tempVal + editValue;
		}
		calculate();

	}else if(buttonID == 4){
		if(isNaN(document.getElementById("c_data4").value)){
			document.getElementById("c_data4").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data4").value == ""){
			document.getElementById("c_data4").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data4").value);
			document.getElementById("c_data4").value = tempVal + editValue;
		}
		calculate();
		
	}else if(buttonID == 5){
		if(isNaN(document.getElementById("c_data5").value)){
			document.getElementById("c_data5").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data5").value == ""){
			document.getElementById("c_data5").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data5").value);
			document.getElementById("c_data5").value = tempVal + editValue;
		}
		calculate();
		
	}else if(buttonID == 6){
		if(isNaN(document.getElementById("c_data6").value)){
			document.getElementById("c_data6").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data6").value == ""){
			document.getElementById("c_data6").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data6").value);
			document.getElementById("c_data6").value = tempVal + editValue;
		}
		calculate();	

	}else if(buttonID == 9){
		if(isNaN(document.getElementById("c_data6b").value)){
			document.getElementById("c_data6b").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data6b").value == ""){
			document.getElementById("c_data6b").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data6b").value);
			document.getElementById("c_data6b").value = tempVal + editValue;
		}
		calculate();
		
	}else if(buttonID == 7){
		if(isNaN(document.getElementById("c_data7").value)){
			document.getElementById("c_data7").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data7").value == ""){
			document.getElementById("c_data7").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data7").value);
			document.getElementById("c_data7").value = tempVal + editValue;
		}
		calculate();

	}else if(buttonID == 8){
		if(isNaN(document.getElementById("c_data8").value)){
			document.getElementById("c_data8").style.backgroundColor = "yellow";
			return;
		}		
		if(document.getElementById("c_data8").value == ""){
			document.getElementById("c_data8").value = editValue;
		}else{
			tempVal = parseInt(document.getElementById("c_data8").value);
			document.getElementById("c_data8").value = tempVal + editValue;
		}
		calculate();

	}
}

