<?php
include 'simple_html_dom.php';
$html = file_get_html('http://www.rentpropcalc.dx.am/index.html');
if(isset($_POST['send']))
{
    $to = $_POST['email'];
    $subject = 'Rental Property Calculator Results';
    
    $header = "From: info@rentpropcalc.dx.am\r\n";
    $header .= 'Content-Type: text/plain; charset=utf-8';
    
    $message = 'Rental Property Calculator Results' . "\r\n\r\n";
    $message .= 'Name of sender: '.$_POST['name'] . "\r\n";
    $message .= 'Email of recipient: '. $_POST['email'] . "\r\n\r\n";
    
    $message .= "Assumed Property Values:"."\r\n\r\n";
    $message .= "Closing Price \t\t$".$_POST['data1_e']."\r\n";
    $message .= "Percent Down \t\t".$_POST['data2_e']."%"."\r\n";
    $message .= "Interest Rate \t\t   ".$_POST['data3_e']."%"."\r\n";
    $message .= "Term Length \t\t".$_POST['data4_e']."\r\n";
    $message .= "Rent Income \t\t$".$_POST['data5_e']."\r\n";
    $message .= "Expenses (%) \t\t  ".$_POST['data6_e']."%"."\r\n";
    $message .= "Expenses ($/yr) \t  ".$_POST['data6b_e']."%"."\r\n";
    $message .= "Closing Costs \t\t$".$_POST['data7_e']."\r\n";
    $message .= "Vacancy Loss \t\t".$_POST['data8_e']."%"."\r\n\r\n\r\n";
    $message .= "Investment Performance:"."\r\n\r\n";
    
    $message .= "CoC Result\t\t\t". $_POST['CoC_result_e']."\r\n";
    $message .= "Cash Flow\t\t\t". $_POST['c_result_e']."\r\n";
    $message .= "Mortgage \t\t\t". $_POST['MORG_result_e']."\r\n";
    $message .= "Expenses \t\t\t". $_POST['EXP_result_e']."\r\n";
    $message .= "Vacancy loss \t\t\t". $_POST['VAC_result_e']."\r\n";
    $message .= "Down Payment \t\t\t". $_POST['DOWN_result_e']."\r\n";
    $message .= "Cash Investment \t\t". $_POST['CASH_result_e']."\r\n";
    $message .= "Loan Amount \t\t\t". $_POST['LOAN_result_e']."\r\n";
    $message .= "Payback Period \t\t\t". $_POST['plusROI_result_e']."\r\n";
    $message .= "1 year ROI \t\t\t". $_POST['ROI_result_e']."\r\n";
    $message .= "CAP Rate \t\t\t". $_POST['CAP_result_e']."\r\n";
    $message .= "GRM \t\t\t\t". $_POST['GRM_result_e']."\r\n";

    
    
}
 $success =  mail($to, $subject, $message, $header) ;
?>


<!DOCTYPE html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<?php
echo '<link href="http://www.rentpropcalc.dx.am/style.css" rel="stylesheet">';

if(isset($success)&& $success)
{
?>
        <div id="endWrapper>
              <div id="returnWrapper">
                      <div id="sentWrapper">
                              <br><br>
                              <p id="sentmsg"> The calculation results have been sent!</p> <br>
                              <input type=button onclick="location.href='index.html'" value='Perform Another Calculation' id="returnButton">
                      </div>
              </div>
              
              <div class="footer">
                       <p>Copyright 2015 Josh Benton, Jon Branham, and Joe Nance.</p>
              </div>
        </div>
      
<?php } //outputs this html if it sends the email
else 
{   ?>

        <div id="endWrapper2">
              <div id="returnWrapper2">
                      <div id="sentWrapper2">
                              <br><br>
                              <p id="sentmsg"> An error occured! <br><br> Please check that the email address used is valid and try again.</p> <br>
                      </div>
              </div>
              
              <div class="footer">
                       <p>Copyright 2015 Josh Benton, Jon Branham, and Joe Nance.</p>
              </div>
        </div>
<h1>Something went wrong</h1>
<p>Check to see if you put in the wrong email address.</p>
<?php    }    ?><!ouputs this html if email did not send>
</body>